package com.sg.sa.springboot.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.sg.sa.springboot.beans.WeatherBean;

@RestController
public class SampleController {
	@GetMapping("/1.0/weathersvc/{city}")
	String currentWeather(@PathVariable final String city) {
		return String.format("Today temp in %s is 30c", city);
	}
	
	@GetMapping("/1.1/weathersvc/{city}")
	WeatherBean currentWeather2(@PathVariable final String city) {
		final WeatherBean output = new WeatherBean();
		
		output.setCity(city);
		output.setTemp("30c");
		
		return output;
	}
	
	@PostMapping("/1.1/weathersvc/add/")
	WeatherBean add(@RequestBody final WeatherBean request, @RequestHeader("x-api-key") final String apiKey ) {
		
		request.setCity(request.getCity());
		request.setTemp(request.getTemp());
		
		System.out.println("API Key:- " + apiKey);
		
		return request;
	}
}
