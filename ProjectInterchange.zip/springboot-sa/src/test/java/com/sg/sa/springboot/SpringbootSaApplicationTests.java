package com.sg.sa.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootSaApplicationTests {

	@Test
	void contextLoads() {
	}

}
